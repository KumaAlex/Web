export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  url: string;
  image1: string;
  image2: string;
  image3: string;
  isActive:boolean;
  likes:number;
  categoryId:number;
  currentCategory:number;
}
export const products = [
  {
    id: 1,
    name: 'Sceptre 24" Professional Thin 75Hz 1080p LED Monitor 2x HDMI VGA Build-in Speakers, Machine Black (E248W-19203R Series)',
    price: 139.97,
    description: `24" Ultra slim profile.
    Contemporary sleek metallic design.
    Slim bezel with thin chassis. Power Range (V, A, Hz)- AC-DC Adapter Input 100 – 240 VAC, 50/60 Hz, 1.0A (Max.) Output - 12V DC, 2.5A. Power Consumption (Typical)- 25.4W. Neck/Stand Detachable: Yes.
    2 x HDMI Ports (convertible to DVI).Contrast Ratio:1000 : 1.
    VESA wall mount ready. HDMI Input Signal Support - 1920 x 1080 @ 75Hz, 1080/60p, 1080/60i, 720p, 480p, 480i, Built-in Speakers - 2 x 2W 8 Ohm.Mounting type: VESA Hole Pattern 100mm x 100mm.
    `,
    url: `https://www.amazon.com/Sceptre-E248W-19203R-Monitor-Speakers-Metallic/dp/B0773ZY26F/ref=sr_1_2?qid=1647170361&s=computers-intl-ship&sr=1-2`,
    image1: `https://m.media-amazon.com/images/I/71rXSVqET9L._AC_SL1257_.jpg`,
    image2: `https://m.media-amazon.com/images/I/61FU4QixmRL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/61QlrzZuj6L._AC_SL1500_.jpg`,
    isActive:true,
    likes:3,
    categoryId:1,
    currentCategory:-1
  },
  {
    id: 2,
    name: 'Original HP 63XL Black High-yield Ink Cartridge | Works with HP DeskJet 1112, 2130, 3630 Series; HP ENVY 4510, 4520 Series; HP OfficeJet 3830, 4650, 5200 Series | Eligible for Instant Ink | F6U64AN',
    price: 41.89,
    description: `Original HP Ink is engineered to work with HP printers to provide consistent quality, reliability and value.
    This cartridge works with: HP DeskJet 1112, 2130, 2132, 3630, 3631, 3632, 3633, 3634, 3636, 3637, 3639; HP ENVY 4511, 4512, 4513, 4516, 4520, 4522, 4524; HP OfficeJet 3830, 3831, 3833, 3836, 4650, 4652, 4654, 4655, 5212, 5222, 5230, 5232, 5255, 5260, 5264.
    Cartridge yield (approx.): 480 pages.
    Up to 2x more prints with Original HP Ink vs. non-Original HP Ink.
    82% of HP ink cartridges are manufactured with recycled plastic.
    Get ink your way: buy Original HP Ink Cartridges or save up to 50% and never run out with HP Instant Ink, the Smart Ink Subscription.
    What's in the box: 1 new Original HP 63XL Black High-yield Ink Cartridge (F6U64AN).
    CHOOSE AN INK REPLENISHMENT SERVICE - Let your printer track usage and have ink delivered before you run out. Either reorder HP Genuine ink cartridges only when you need them through Amazon Dash Replenishment, or save up to 50 percent by paying for pages printed through HP Instant Ink`,
    url: `https://www.amazon.com/HP-Cartridge-F6U64AN-Deskjet-Officejet/dp/B00WJDWGA8/ref=sr_1_7?qid=1647170361&s=computers-intl-ship&sr=1-7`,
    image1: `https://m.media-amazon.com/images/I/71dknWOvquL._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71gKwq1Z3oL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71gKwq1Z3oL._AC_SL1500_.jpg`,
    isActive:true,
    likes:7,
    categoryId:1,
    currentCategory:-1
  },
  {
    id: 3,
    name: 'Logitech Brio 4K Webcam, Ultra 4K HD Video Calling, Noise-Canceling mic, HD Auto Light Correction, Wide Field of View, Works with Microsoft Teams, Zoom, Google Voice, PC/Mac/Laptop/Macbook/Tablet',
    price: 199.99,
    description: `Ultra 4K HD resolution: 4 times the resolution of a typical HD webcam; look your best and enjoy professional video experience wherever you are with 5x HD zoom.
    Auto light adjustment: Logitech RightLight 3 uses HDR technology to show you in the best light, even in low-light and backlit situations.
    Noise-canceling technology: Dual omni-directional mics suppress background sound so you can be heard clearly.
    3 field of view presets: Choose 90°, 78° or 65° dFOV via Logi Tune to include more of your environment or narrow the focus on you.
    Up to 90 fps: Create high-quality video recording or streaming in any light condition.
    Windows Hello integration: Easily and securely sign into your computer without a password.
    Privacy shade: Flip up or and down to cover or expose the lens.
    Works with Windows, Mac, or ChromeOS and popular calling and streaming platforms; 1 year limited hardware warranty.
    `,
    url: `https://www.amazon.com/Logitech-Calling-Noise-Canceling-Correction-Microsoft/dp/B01N5UOYC4/ref=sr_1_12?qid=1647170361&s=computers-intl-ship&sr=1-12&th=1`,
    image1: `https://m.media-amazon.com/images/I/61OQP2+yqML._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/81fPB0huYUL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71nvccxLOgL._AC_SL1500_.jpg`,
    isActive:true,
    likes:0,
    categoryId:1,
    currentCategory:-1
  },
  {
    id: 4,
    name: 'Tablet with Keyboard 5G Dual Wi-Fi Android 10.0, AOYODKG Tablet 10 inch 1920x1200 HD IPS, 4GB RAM, 64GB ROM, Dual Camera, Bluetooth,GPS,Type-C,Include Keyboard,Mouse,Tablet Case and More (Gold)',
    price: 148.0,
    description: `【More practical accessories】 Extra accessories gift: Standard accessories package: 10.1-inch tablet, protective leather case, protective film (attached), charger, type-C charging cable, instruction manual Additional accessories: wireless mouse, Bluetooth keyboard, OTG adapter, With the accessories we give away, you can easily turn your tablet into a laptop for office work. Suitable for gifts.
    【High-performance processor】--- The world’s latest Android 10.0 system, is a GMS certified, you can fully access Play Store and better applications and content in the Play Store. 64-bit quad-core high-performance processor, fast application startup, smooth game video, and excellent overall performance.
    【Large Storage Capacity】--- Our tablet is packed with 4GB RAM 64GB ROM(128GB expansion）, which help to do more of what you want. Upgraded memory and powerful processing speeds means you could do more and keep more. 5MP+8MP camera will give you stunning brightness and clarity.
    【2.4Ghz+5GHz Dual WiFi fast connection】--- 10.1-inch tablet supports 2.4G+5G WiFi to achieve faster speed to offer you smooth and stable connection. Forget about long buffering and frame freezing, coupled BT5.0 with GPS and other mainstream navigation systems, our tablet will make it easy to download or watch video online and allow you to reach destination quickly.
    【BRILLIANT IPS DISPLAY】-- AOYODKG tablet 10 inch adopts a 1920*1200 brilliant HD IPS display. Enjoying brilliant colors, crisp text, and vivid video viewing when you watch videos or play games. This android tablet has a sharp hierarchy of images and rich colors, and provides shocking performance of visual experience. The Eye Health mode optimizes the backlight for a more comfortable reading experience.`,
    url: `https://www.amazon.com/Android-Keyboard-Quad-Core-Bluetooth-Certified/dp/B092ZPTCZG/ref=sr_1_2_sspa?qid=1647108449&s=computers-intl-ship&sr=1-2-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEzRU5ONkpGTlJERjJGJmVuY3J5cHRlZElkPUEwOTkzNzExM1A3VTk3VTJYUDBJMCZlbmNyeXB0ZWRBZElkPUEwNDgyODE1MzYxWjE2UTJVOVY4WSZ3aWRnZXROYW1lPXNwX2F0Zl9icm93c2UmYWN0aW9uPWNsaWNrUmVkaXJlY3QmZG9Ob3RMb2dDbGljaz10cnVl`,
    image1: `https://m.media-amazon.com/images/I/71-N2XDfn-S._AC_SX466_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71zqVWO6MsL._AC_SX466_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71RVaZfODtL._AC_SX466_.jpg`,
    isActive:true,
    likes:0,
    categoryId:1,
    currentCategory:-1
  },
  {
    id: 5,
    name: 'Lenovo IdeaPad 3 11 Chromebook Laptop, 11.6" HD Display, Intel Celeron N4020, 4GB RAM, 64GB Storage, Intel UHD Graphics 600, Chrome OS',
    price: 188.0,
    description: `No setup required. Log in to your Chromebook laptop with your Google account and you're ready to go. Easy access to collaborative tools on G Suite and the full library of apps on Google Play`,
    url: `https://https://www.amazon.com/Lenovo-Chromebook-Processor-Graphics-82BA0003US/dp/B087YW8FQB/ref=sr_1_3?qid=1647091689&s=computers-intl-ship&sr=1-3`,
    image1: `https://m.media-amazon.com/images/I/71XIwK5G75L._AC_SX466_.jpg`,
    image2: `https://m.media-amazon.com/images/I/61DBhNhTpYL._AC_SX466_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71+YKl8hMjL._AC_SX466_.jpg`,
    isActive:true,
    likes:0,
    categoryId:1,
    currentCategory:-1
  },


  {
    id: 6,
    name: 'Samsung Galaxy S7 G930T 32GB T-Mobile Unlocked 4G LTE Quad-Core Phone w/ 12MP Camera - Gold',
    price: 159.99,
    description: `Products with electrical plugs are designed for use in the US. Outlets and voltage differ internationally and this product may require an adapter or converter for use in your destination. Please check compatibility before purchasing.`,
    url: `https://www.amazon.com/Samsung-Galaxy-G930T-T-Mobile-Unlocked/dp/B077MR13HM/ref=sr_1_1?crid=31KNM1JJEFVJ1&keywords=phones+on+sale&qid=1647171286&sprefix=phone%2Cspecialty-aps%2C301&sr=8-1`,
    image1: `https://m.media-amazon.com/images/I/61OCfRvtCEL._AC_SL1054_.jpg`,
    image2: `https://www.bhphotovideo.com/images/images500x500/samsung_sm5g930tzkatmb_galaxy_s7_g930t_unlocked_1382830.jpg`,
    image3: `https://m.phonegg.com/71/7180b-1.jpg`,
    isActive:true,
    likes:2,
    categoryId:2,
    currentCategory:-1
  },
  {
    id: 7,
    name: 'Total Wireless Blu View 2 4G LTE Prepaid Smartphone (Locked) - Black - 32GB - Sim Card Included - CDMA',
    price: 139.99,
    description: `CARRIER: This phone is locked to Total Wireless, which means this device can only be used on the Total Wireless wireless network.
    5.5" HD Display; 2.0GHz Quad-Core Processor; Android 10; 3,000mAh Battery
    4G LTE; Wi-Fi Connectivity – 802.11 b/g/n; Bluetooth 5.1 wireless technology
    13MP Rear Camera + LED Flash/8MP Front-Facing Selfie Camera; Internal memory 32GB; 2GB RAM; Supports Micro SD up to 128GB (not included)
    Unlimited Talk, Text and Data plans starting as low as $20/month.
    `,
    url: `https://www.amazon.com/dp/B07XWGWPH5/ref=syn_sd_onsite_desktop_179?psc=1&pd_rd_plhdr=t&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEySFg2V0NYTkJZNjRYJmVuY3J5cHRlZElkPUEwOTE5MzI3MVpKRERUR0ZBVUVCSiZlbmNyeXB0ZWRBZElkPUEwODEzMzQ2MTlBUTlHQzI5MkZLOSZ3aWRnZXROYW1lPXNkX29uc2l0ZV9kZXNrdG9wJmFjdGlvbj1jbGlja1JlZGlyZWN0JmRvTm90TG9nQ2xpY2s9dHJ1ZQ==`,
    image1: `https://m.media-amazon.com/images/I/41LvNVPW-TL._AC_SR38,50_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71ZqDPMzlWL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/714h8GVphWL._AC_SL1500_.jpg`,
    isActive:true,
    likes:123,
    categoryId:2,
    currentCategory:-1
  },
  {
    id: 8,
    name: 'OnePlus Nord N200 | 5G Unlocked Android Smartphone U.S Version | 6.49" Full HD+LCD Screen | 90Hz Smooth Display | Large 5000mAh Battery | Fast Charging | 64GB Storage | Triple Camera,Blue Quantum',
    price: 499.99,
    description: `5G Enabled (5G service only available on T-Mobile and Google Fi) - Powered by the latest Qualcomm 5G chipset, the OnePlus Nord N200 5G allows you to download or stream your favorite TV shows, connect with your social media, and play online multiplayer at blazing fast speeds.
    6.49” Full HD+ LCD Display, 90Hz Smooth Display - Immerse yourself in all your favorite movies, TV shows, and video games with N200 5G’s 6.49” crystal clear Full HD+ display.
    90Hz Smooth Display - The 90Hz refresh rate refreshes 50% faster than standard 60Hz displays, ensuring smooth navigation and scrolling across the home screen and your applications.`,
    url: `https://www.amazon.com/Total-Wireless-Prepaid-Smartphone-Locked/dp/B08J5L3HHT/ref=sr_1_1?keywords=smartphone&qid=1647154598&sr=8-1`,
    image1: `https://m.media-amazon.com/images/I/71DCZOdq92S._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71xFRmip0iS._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/61J2rvijhZS._AC_SL1500_.jpg`,
    isActive:true,
    likes:0,
    categoryId:2,
    currentCategory:-1
  },
  {
    id: 9,
    name: 'Total Wireless Blu View 2 4G LTE Prepaid Smartphone (Locked) - Black - 32GB - Sim Card Included - CDMA',
    price: 139.99,
    description: `CARRIER: This phone is locked to Total Wireless, which means this device can only be used on the Total Wireless wireless network.
    5.5" HD Display; 2.0GHz Quad-Core Processor; Android 10; 3,000mAh Battery
    4G LTE; Wi-Fi Connectivity – 802.11 b/g/n; Bluetooth 5.1 wireless technology
    13MP Rear Camera + LED Flash/8MP Front-Facing Selfie Camera; Internal memory 32GB; 2GB RAM; Supports Micro SD up to 128GB (not included)
    Unlimited Talk, Text and Data plans starting as low as $20/month.
    `,
    url: `https://www.amazon.com/dp/B07XWGWPH5/ref=syn_sd_onsite_desktop_179?psc=1&pd_rd_plhdr=t&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEySFg2V0NYTkJZNjRYJmVuY3J5cHRlZElkPUEwOTE5MzI3MVpKRERUR0ZBVUVCSiZlbmNyeXB0ZWRBZElkPUEwODEzMzQ2MTlBUTlHQzI5MkZLOSZ3aWRnZXROYW1lPXNkX29uc2l0ZV9kZXNrdG9wJmFjdGlvbj1jbGlja1JlZGlyZWN0JmRvTm90TG9nQ2xpY2s9dHJ1ZQ==`,
    image1: `https://m.media-amazon.com/images/I/41LvNVPW-TL._AC_SR38,50_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71ZqDPMzlWL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/714h8GVphWL._AC_SL1500_.jpg`,
    isActive:true,
    likes:123,
    categoryId:2,
    currentCategory:-1
  },
  {
    id: 10,
    name: 'OnePlus Nord N200 | 5G Unlocked Android Smartphone U.S Version | 6.49" Full HD+LCD Screen | 90Hz Smooth Display | Large 5000mAh Battery | Fast Charging | 64GB Storage | Triple Camera,Blue Quantum',
    price: 499.99,
    description: `5G Enabled (5G service only available on T-Mobile and Google Fi) - Powered by the latest Qualcomm 5G chipset, the OnePlus Nord N200 5G allows you to download or stream your favorite TV shows, connect with your social media, and play online multiplayer at blazing fast speeds.
    6.49” Full HD+ LCD Display, 90Hz Smooth Display - Immerse yourself in all your favorite movies, TV shows, and video games with N200 5G’s 6.49” crystal clear Full HD+ display.
    90Hz Smooth Display - The 90Hz refresh rate refreshes 50% faster than standard 60Hz displays, ensuring smooth navigation and scrolling across the home screen and your applications.`,
    url: `https://www.amazon.com/Total-Wireless-Prepaid-Smartphone-Locked/dp/B08J5L3HHT/ref=sr_1_1?keywords=smartphone&qid=1647154598&sr=8-1`,
    image1: `https://m.media-amazon.com/images/I/71DCZOdq92S._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71xFRmip0iS._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/61J2rvijhZS._AC_SL1500_.jpg`,
    isActive:true,
    likes:245634568647,
    categoryId:2,
    currentCategory:-1
  },


  {
    id: 11,
    name: 'Tarok Pro - Razer Edition Gaming Chair by Zen - Lime Green Gaming Chair - Reclining Ergonomic Desk Office Chair – Adjustable Game Chair, Lumbar Support, Memory Foam Pillow, Comfortable Zen Work Chair',
    price: 389.99,
    description: `VELVET COVERED MEMORY FOAM PILLOWS - Included with the TAROK PRO gaming chair is a set of velvet-covered memory foam pillows, one provides neck support when reclining and the other for the lumbar support of the lower back – adjustable height positioning to ensure optimal support. For the longest gaming sessions.`,
    url: `https://www.amazon.com/Eureka-PowerSpeed-Bagless-Upright-Cleaner/dp/B083C2DTKX/ref=sr_1_1?keywords=vacuum%2Bcleaner&qid=1647166398&sr=8-1&th=1`,
    image1: `https://m.media-amazon.com/images/I/61W18sIUC-L._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/81VxSqWpQjL._AC_SL1300_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71r-AX-npuL._AC_SL1500_.jpg`,
    isActive:true,
    likes:245845,
    categoryId:3,
    currentCategory:-1
  },
  {
    id: 12,
    name: 'https://www.amazon.com/YSSOA-Gaming-Office-Adjustable-Chair/dp/B08XQNSH7B/ref=sr_1_6?keywords=gaming+chairs&pd_rd_r=9d37a9c3-8181-4b45-9e86-2444ff7bc44d&pd_rd_w=nabw3&pd_rd_wg=i9RsE&pf_rd_p=12129333-2117-4490-9c17-6d31baf0582a&pf_rd_r=3FB2NC4SBVWS2N1ZSJPK&qid=1647171922&sr=8-6',
    price: 99.99,
    description: `Powerful vacuum cleaner The dynamic motor and brush roll can lift stubborn and heavy debris Plus the 12 6” wide nozzle cleans more with a quickness`,
    url: `[Ergonomic Support Backrest] The ergonomic body-hugging high back provides lumbar support and naturally follows your spine's natural curve. It is tall enough to support your entire spine. The back can be adjusted from 90° to 120°. The ergonomic armrest allows you to put hands on the armrest to relax.
    [Comfortable Seat] Thick and high-density sponge cushion provides sufficient seat depth to reduce stress and pressure on your hips. The lumbar cushion and headrest pillow will protect and relax your spinal and neck. Easy to assemble.
    [Retractable Footrest] With the retractable footrest，you can relieve tension on your legs and knees.
    [Adjustable Chair] You can adjust the 3-inch height to sit with your feet flat on the floor, knees at an angle of 90 degrees to the floor and parallel to the hips. 360° free swivel seat help you find the most comfort position.`,
    image1: `https://m.media-amazon.com/images/I/61O4ilN5v1S._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71xC6TF+AnL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71gysQycsgL._AC_SL1500_.jpg`,
    isActive:true,
    likes:3456,
    categoryId:3,
    currentCategory:-1
  },
  {
    id: 13,
    name: 'Tarok Pro - Razer Edition Gaming Chair by Zen - Lime Green Gaming Chair - Reclining Ergonomic Desk Office Chair – Adjustable Game Chair, Lumbar Support, Memory Foam Pillow, Comfortable Zen Work Chair',
    price: 389.99,
    description: `VELVET COVERED MEMORY FOAM PILLOWS - Included with the TAROK PRO gaming chair is a set of velvet-covered memory foam pillows, one provides neck support when reclining and the other for the lumbar support of the lower back – adjustable height positioning to ensure optimal support. For the longest gaming sessions.`,
    url: `https://www.amazon.com/Eureka-PowerSpeed-Bagless-Upright-Cleaner/dp/B083C2DTKX/ref=sr_1_1?keywords=vacuum%2Bcleaner&qid=1647166398&sr=8-1&th=1`,
    image1: `https://m.media-amazon.com/images/I/61W18sIUC-L._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/81VxSqWpQjL._AC_SL1300_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71r-AX-npuL._AC_SL1500_.jpg`,
    isActive:true,
    likes:8765,
    categoryId:3,
    currentCategory:-1
  },
  {
    id: 14,
    name: 'https://www.amazon.com/YSSOA-Gaming-Office-Adjustable-Chair/dp/B08XQNSH7B/ref=sr_1_6?keywords=gaming+chairs&pd_rd_r=9d37a9c3-8181-4b45-9e86-2444ff7bc44d&pd_rd_w=nabw3&pd_rd_wg=i9RsE&pf_rd_p=12129333-2117-4490-9c17-6d31baf0582a&pf_rd_r=3FB2NC4SBVWS2N1ZSJPK&qid=1647171922&sr=8-6',
    price: 99.99,
    description: `Powerful vacuum cleaner The dynamic motor and brush roll can lift stubborn and heavy debris Plus the 12 6” wide nozzle cleans more with a quickness`,
    url: `[Ergonomic Support Backrest] The ergonomic body-hugging high back provides lumbar support and naturally follows your spine's natural curve. It is tall enough to support your entire spine. The back can be adjusted from 90° to 120°. The ergonomic armrest allows you to put hands on the armrest to relax.
    [Comfortable Seat] Thick and high-density sponge cushion provides sufficient seat depth to reduce stress and pressure on your hips. The lumbar cushion and headrest pillow will protect and relax your spinal and neck. Easy to assemble.
    [Retractable Footrest] With the retractable footrest，you can relieve tension on your legs and knees.
    [Adjustable Chair] You can adjust the 3-inch height to sit with your feet flat on the floor, knees at an angle of 90 degrees to the floor and parallel to the hips. 360° free swivel seat help you find the most comfort position.`,
    image1: `https://m.media-amazon.com/images/I/61O4ilN5v1S._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71xC6TF+AnL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71gysQycsgL._AC_SL1500_.jpg`,
    isActive:true,
    likes:0,
    categoryId:3,
    currentCategory:-1
  },
  {
    id: 15,
    name: 'Tarok Pro - Razer Edition Gaming Chair by Zen - Lime Green Gaming Chair - Reclining Ergonomic Desk Office Chair – Adjustable Game Chair, Lumbar Support, Memory Foam Pillow, Comfortable Zen Work Chair',
    price: 389.99,
    description: `VELVET COVERED MEMORY FOAM PILLOWS - Included with the TAROK PRO gaming chair is a set of velvet-covered memory foam pillows, one provides neck support when reclining and the other for the lumbar support of the lower back – adjustable height positioning to ensure optimal support. For the longest gaming sessions.`,
    url: `https://www.amazon.com/Eureka-PowerSpeed-Bagless-Upright-Cleaner/dp/B083C2DTKX/ref=sr_1_1?keywords=vacuum%2Bcleaner&qid=1647166398&sr=8-1&th=1`,
    image1: `https://m.media-amazon.com/images/I/61W18sIUC-L._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/81VxSqWpQjL._AC_SL1300_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71r-AX-npuL._AC_SL1500_.jpg`,
    isActive:true,
    likes:78,
    categoryId:3,
    currentCategory:-1
  },


  {
    id: 16,
    name: 'Redragon S101 Wired Gaming Keyboard and Mouse Combo RGB Backlit Gaming Keyboard with Multimedia Keys Wrist Rest and Red Backlit Gaming Mouse 3200 DPI for Windows PC Gamers (Black)',
    price: 35.98,
    description: `PC GAMING KEYBOARD AND GAMING MOUSE COMBO: Includes Redragon RGB Backlit Computer Gaming Keyboard and RGB Backlit Gaming Mouse. ALL-IN-ONE PC GAMER VALUE KIT, Fantastic for Gamers (New Improved Version)`,
    url: `https://www.amazon.com/Redragon-S101-Keyboard-Ergonomic-Programmable/dp/B00NLZUM36/ref=sr_1_2_sspa?keywords=gaming%2Bkeyboard&pd_rd_r=9d37a9c3-8181-4b45-9e86-2444ff7bc44d&pd_rd_w=nabw3&pd_rd_wg=i9RsE&pf_rd_p=12129333-2117-4490-9c17-6d31baf0582a&pf_rd_r=3FB2NC4SBVWS2N1ZSJPK&qid=1647172021&sr=8-2-spons&smid=AXZ7TDMJNMJSZ&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyUDRaS0w0TTQxRUhJJmVuY3J5cHRlZElkPUEwOTM1Njc3MzU4Q0RCN0tGT0wzSSZlbmNyeXB0ZWRBZElkPUEwNTAzODM4MjY2Q0M3VFIxQTRYRCZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU&th=1`,
    image1: `https://m.media-amazon.com/images/I/71kr3WAj1FL._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71uIslKmtoL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71H6y1GGbAL._AC_SL1500_.jpg`,
    isActive:true,
    likes:43,
    categoryId:4,
    currentCategory:-1
  },
  {
    id: 17,
    name: 'Redragon S101 Wired Gaming Keyboard and Mouse Combo RGB Backlit Gaming Keyboard with Multimedia Keys Wrist Rest and Red Backlit Gaming Mouse 3200 DPI for Windows PC Gamers (Black)',
    price: 35.98,
    description: `PC GAMING KEYBOARD AND GAMING MOUSE COMBO: Includes Redragon RGB Backlit Computer Gaming Keyboard and RGB Backlit Gaming Mouse. ALL-IN-ONE PC GAMER VALUE KIT, Fantastic for Gamers (New Improved Version)`,
    url: `https://www.amazon.com/Redragon-S101-Keyboard-Ergonomic-Programmable/dp/B00NLZUM36/ref=sr_1_2_sspa?keywords=gaming%2Bkeyboard&pd_rd_r=9d37a9c3-8181-4b45-9e86-2444ff7bc44d&pd_rd_w=nabw3&pd_rd_wg=i9RsE&pf_rd_p=12129333-2117-4490-9c17-6d31baf0582a&pf_rd_r=3FB2NC4SBVWS2N1ZSJPK&qid=1647172021&sr=8-2-spons&smid=AXZ7TDMJNMJSZ&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyUDRaS0w0TTQxRUhJJmVuY3J5cHRlZElkPUEwOTM1Njc3MzU4Q0RCN0tGT0wzSSZlbmNyeXB0ZWRBZElkPUEwNTAzODM4MjY2Q0M3VFIxQTRYRCZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU&th=1`,
    image1: `https://m.media-amazon.com/images/I/71kr3WAj1FL._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71uIslKmtoL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71H6y1GGbAL._AC_SL1500_.jpg`,
    isActive:true,
    likes:4,
    categoryId:4,
    currentCategory:-1
  },
  {
    id: 18,
    name: 'Redragon S101 Wired Gaming Keyboard and Mouse Combo RGB Backlit Gaming Keyboard with Multimedia Keys Wrist Rest and Red Backlit Gaming Mouse 3200 DPI for Windows PC Gamers (Black)',
    price: 35.98,
    description: `PC GAMING KEYBOARD AND GAMING MOUSE COMBO: Includes Redragon RGB Backlit Computer Gaming Keyboard and RGB Backlit Gaming Mouse. ALL-IN-ONE PC GAMER VALUE KIT, Fantastic for Gamers (New Improved Version)`,
    url: `https://www.amazon.com/Redragon-S101-Keyboard-Ergonomic-Programmable/dp/B00NLZUM36/ref=sr_1_2_sspa?keywords=gaming%2Bkeyboard&pd_rd_r=9d37a9c3-8181-4b45-9e86-2444ff7bc44d&pd_rd_w=nabw3&pd_rd_wg=i9RsE&pf_rd_p=12129333-2117-4490-9c17-6d31baf0582a&pf_rd_r=3FB2NC4SBVWS2N1ZSJPK&qid=1647172021&sr=8-2-spons&smid=AXZ7TDMJNMJSZ&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyUDRaS0w0TTQxRUhJJmVuY3J5cHRlZElkPUEwOTM1Njc3MzU4Q0RCN0tGT0wzSSZlbmNyeXB0ZWRBZElkPUEwNTAzODM4MjY2Q0M3VFIxQTRYRCZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU&th=1`,
    image1: `https://m.media-amazon.com/images/I/71kr3WAj1FL._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71uIslKmtoL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71H6y1GGbAL._AC_SL1500_.jpg`,
    isActive:true,
    likes:34,
    categoryId:4,
    currentCategory:-1
  }, 
  {
    id: 19,
    name: 'Redragon S101 Wired Gaming Keyboard and Mouse Combo RGB Backlit Gaming Keyboard with Multimedia Keys Wrist Rest and Red Backlit Gaming Mouse 3200 DPI for Windows PC Gamers (Black)',
    price: 35.98,
    description: `PC GAMING KEYBOARD AND GAMING MOUSE COMBO: Includes Redragon RGB Backlit Computer Gaming Keyboard and RGB Backlit Gaming Mouse. ALL-IN-ONE PC GAMER VALUE KIT, Fantastic for Gamers (New Improved Version)`,
    url: `https://www.amazon.com/Redragon-S101-Keyboard-Ergonomic-Programmable/dp/B00NLZUM36/ref=sr_1_2_sspa?keywords=gaming%2Bkeyboard&pd_rd_r=9d37a9c3-8181-4b45-9e86-2444ff7bc44d&pd_rd_w=nabw3&pd_rd_wg=i9RsE&pf_rd_p=12129333-2117-4490-9c17-6d31baf0582a&pf_rd_r=3FB2NC4SBVWS2N1ZSJPK&qid=1647172021&sr=8-2-spons&smid=AXZ7TDMJNMJSZ&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyUDRaS0w0TTQxRUhJJmVuY3J5cHRlZElkPUEwOTM1Njc3MzU4Q0RCN0tGT0wzSSZlbmNyeXB0ZWRBZElkPUEwNTAzODM4MjY2Q0M3VFIxQTRYRCZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU&th=1`,
    image1: `https://m.media-amazon.com/images/I/71kr3WAj1FL._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71uIslKmtoL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71H6y1GGbAL._AC_SL1500_.jpg`,
    isActive:true,
    likes:70,
    categoryId:4,
    currentCategory:-1
  }, 
  {
    id: 20,
    name: 'Redragon S101 Wired Gaming Keyboard and Mouse Combo RGB Backlit Gaming Keyboard with Multimedia Keys Wrist Rest and Red Backlit Gaming Mouse 3200 DPI for Windows PC Gamers (Black)',
    price: 35.98,
    description: `PC GAMING KEYBOARD AND GAMING MOUSE COMBO: Includes Redragon RGB Backlit Computer Gaming Keyboard and RGB Backlit Gaming Mouse. ALL-IN-ONE PC GAMER VALUE KIT, Fantastic for Gamers (New Improved Version)`,
    url: `https://www.amazon.com/Redragon-S101-Keyboard-Ergonomic-Programmable/dp/B00NLZUM36/ref=sr_1_2_sspa?keywords=gaming%2Bkeyboard&pd_rd_r=9d37a9c3-8181-4b45-9e86-2444ff7bc44d&pd_rd_w=nabw3&pd_rd_wg=i9RsE&pf_rd_p=12129333-2117-4490-9c17-6d31baf0582a&pf_rd_r=3FB2NC4SBVWS2N1ZSJPK&qid=1647172021&sr=8-2-spons&smid=AXZ7TDMJNMJSZ&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUEyUDRaS0w0TTQxRUhJJmVuY3J5cHRlZElkPUEwOTM1Njc3MzU4Q0RCN0tGT0wzSSZlbmNyeXB0ZWRBZElkPUEwNTAzODM4MjY2Q0M3VFIxQTRYRCZ3aWRnZXROYW1lPXNwX2F0ZiZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU&th=1`,
    image1: `https://m.media-amazon.com/images/I/71kr3WAj1FL._AC_SL1500_.jpg`,
    image2: `https://m.media-amazon.com/images/I/71uIslKmtoL._AC_SL1500_.jpg`,
    image3: `https://m.media-amazon.com/images/I/71H6y1GGbAL._AC_SL1500_.jpg`,
    isActive:true,
    likes:35,
    categoryId:4,
    currentCategory:-1
  },
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
